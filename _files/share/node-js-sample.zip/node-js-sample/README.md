# Container rodando node-js

Uma app simples em node usando [Express 4](http://expressjs.com/) baseado no exemplo  ["Dockerizing a Node.js web app"](https://nodejs.org/en/docs/guides/nodejs-docker-webapp/) da paǵina [https://nodejs.org](https://nodejs.org);

## Build da Imagem

Na pasta raiz do projeto crie um Dockerfile com as especificacoes abaixo:

```sh
FROM node:carbon

# Diretorio de exec. da aplicacao
WORKDIR /usr/src/app

# Copiando dependencias
COPY package.json ./

# Instalando dependencias
RUN npm install

# Copiar tudo que esta no diretorio corrente para o WORKDIR
COPY . /usr/src/app

# Porta onde a aplicacao recebe conexoes
# (Será necessario o uso da variavel de ambiente PORT para mudar o comportamento default)
# (Verifique como essa config foi estabelecida na linha 4 do arquivo index.js)
EXPOSE 8080

# Execucao sa aplicacao usando CMD (Comando a ser executado pelo container)
CMD [ "npm", "start" ]
```

Em seguida faça o build de seu novo container_

```sh
docker build -t mynode-app .
```

## Executando o container

Por padrao ao executar seu container ele utiliza a porta [localhost:5000](http://localhost:5000/) do node, dessa forma para rodar seu container alterando a porta utilize a propriedade PORT, um recursos da propria linguagem node:

```sh
docker run -d -p 8080:8080 -e PORT=8080 mynode-app
```