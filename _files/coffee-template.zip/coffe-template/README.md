
Documentação da imagem usada: https://hub.docker.com/_/httpd/
Template usado neste exemplo: https://www.w3schools.com/w3css/tryit.asp?filename=tryw3css_templates_cafe

Para criar o Dockerfile proceda conforme abaixo:

1. Crie um arquivo Dockerfile conforme modelo abaixo:

```sh
FROM httpd:2.4
COPY ./public-html/ /usr/local/apache2/htdocs/
```

2. Em seguida apenas execute os comandos necessários para o processo de build:

```sh
$ docker build -t my-apache2 .
```

3. Finalmente teste seu novo container rodando o seguinte:

```sh
$ docker run -dit --name my-running-app my-apache2
```
